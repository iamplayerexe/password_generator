const { app } = require('electron');
const { initializeApp } = require('./src/js/main/app-lifecycle');
const { setupIpcHandlers } = require('./src/js/main/ipc-handlers');

// Set up all IPC listeners before the app is ready
setupIpcHandlers();

// Start the application lifecycle
app.whenReady().then(initializeApp);